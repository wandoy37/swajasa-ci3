<section id="mitra">
    <div class="container">
        <div class="row text-center align-items-center">
            <div class="col-sm">
                <img src="<?php echo base_url() . 'assets/landingpages' ?>/img/mitra/1.png" class="img-fluid" width="50px" alt="">
            </div>
            <div class="col-sm">
                <img src="<?php echo base_url() . 'assets/landingpages' ?>/img/mitra/2.png" class="img-fluid" width="50px" alt="">
            </div>
            <div class="col-sm">
                <img src="<?php echo base_url() . 'assets/landingpages' ?>/img/mitra/3.png" class="img-fluid" width="50px" alt="">
            </div>
            <div class="col-sm">
                <img src="<?php echo base_url() . 'assets/landingpages' ?>/img/mitra/4.png" class="img-fluid" width="50px" alt="">
            </div>
            <div class="col-sm">
                <img src="<?php echo base_url() . 'assets/landingpages' ?>/img/mitra/5.png" class="img-fluid" width="50px" alt="">
            </div>
            <div class="col-sm">
                <img src="<?php echo base_url() . 'assets/landingpages' ?>/img/mitra/6.png" class="img-fluid" width="50px" alt="">
            </div>
        </div>
    </div>
</section>